package com.tonso.pcompiler;

public class CompilerSyntaxException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public CompilerSyntaxException(String exceptionText) {
		super(exceptionText);
	}
}
