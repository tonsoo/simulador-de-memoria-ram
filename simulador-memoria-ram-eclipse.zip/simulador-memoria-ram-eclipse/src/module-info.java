/**
 * 
 */
/**
 * @author tonso
 *
 */
module pcSimulator {
	requires java.desktop;
}